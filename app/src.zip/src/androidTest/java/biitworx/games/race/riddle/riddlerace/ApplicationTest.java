package biitworx.games.race.riddle.riddlerace;

import android.app.Application;
import android.test.ApplicationTestCase;
import android.test.suitebuilder.annotation.SmallTest;

import java.math.BigDecimal;

import biitworx.games.race.riddle.riddlerace.shop.MockShopService;
import biitworx.games.race.riddle.riddlerace.shop.ShopBase;

/**
 * <a href="http://d.android.com/tools/testing/testing_android.html">Testing Fundamentals</a>
 */
public class ApplicationTest extends ApplicationTestCase<Application> {
    public ApplicationTest() {
        super(Application.class);

    }


}