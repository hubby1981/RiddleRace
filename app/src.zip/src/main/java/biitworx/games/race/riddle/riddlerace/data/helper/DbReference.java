package biitworx.games.race.riddle.riddlerace.data.helper;

/**
 * Created by marcel.weissgerber on 25.05.2016.
 */
public @interface DbReference {
    Class items();
}
