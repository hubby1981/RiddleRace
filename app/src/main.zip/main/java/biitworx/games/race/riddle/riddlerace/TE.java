package biitworx.games.race.riddle.riddlerace;

/**
 * Created by marcel.weissgerber on 13.10.2016.
 */

public class TE {

    public static String get(int id){
        return MainMenu.res.getString(id);
    }
}
