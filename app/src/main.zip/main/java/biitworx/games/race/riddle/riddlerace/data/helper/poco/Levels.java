package biitworx.games.race.riddle.riddlerace.data.helper.poco;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import biitworx.games.race.riddle.riddlerace.MainMenu;
import biitworx.games.race.riddle.riddlerace.R;
import biitworx.games.race.riddle.riddlerace.TE;


/**
 * Created by marce_000 on 12.10.2016.
 */
public class Levels {


    private static List<LevelSet> sets = new ArrayList<>();

    static {
        sets = MainMenu.DATA.getData(LevelSet.class, MainMenu.DATA.get(), true);
        if (sets == null || sets.size() == 0) {
            setupSets();
        }

    }

    public static Level getLevel(UUID id) {
        Level r = null;
        for (LevelSet s : sets) {
            for (Level l : s.getLevels()) {
                if (l.getUID().equals(id)) {
                    r = l;
                    break;
                }
            }
        }
        return r;
    }

    public static LevelSet getLevelSet(UUID id) {
        Level r = null;
        for (LevelSet s : sets) {
            for (Level l : s.getLevels()) {
                if (l.getUID().equals(id)) {
                    return s;

                }
            }
        }
        return null;
    }

    public static LevelSet getSet(String name) {
        for (LevelSet s : sets)
            if (s.getName().equals(name))
                return s;
        return null;
    }

    public static void removeLevel(Level level) {

    }

    public static void updateLevel(Level level, boolean insert) {

        MainMenu.DATA.insert(level, insert, MainMenu.DATA.get());

        LevelSet bundle = null;
        for (LevelSet b : sets) {
            if (b.getLevels().contains(level)) {
                bundle = b;
            }
        }
        if (bundle != null) {
            int stars = 0;
            for (Level l : bundle.getLevels()) {
                stars += l.getScore() >= l.getMax() ? 3 : l.getScore() >= l.getMed() ? 2 : l.getScore() >= l.getMin() ? 1 : 0;
            }
            bundle.setCollected(stars);
            MainMenu.DATA.insert(bundle, false, MainMenu.DATA.get());

        }

    }

    public static int[] getRedArray() {
        return new int[]{76, 224, 33, 103, 255, 0, 205, 233, 25, 253};
    }

    public static int[] getGreenArray() {
        return new int[]{175, 67, 150, 58, 87, 150, 220, 30, 25, 216};
    }

    public static int[] getBlueArray() {
        return new int[]{80, 54, 243, 183, 34, 136, 57, 99, 25, 53};
    }

    public static void updateSet(LevelSet set) {
        MainMenu.DATA.insert(set, false, MainMenu.DATA.get());
    }

    private static void setupSets() {
        sets.add(setupBasicSet());
    }

    private static LevelSet setupBasicSet() {
        LevelSet result = new LevelSet(TE.get(R.string.bundle_basic), 40);


        for (Level l : result.getLevels())
            MainMenu.DATA.insert(l, true, MainMenu.DATA.get());

        MainMenu.DATA.insert(result, true, MainMenu.DATA.get());

        return result;
    }

}
