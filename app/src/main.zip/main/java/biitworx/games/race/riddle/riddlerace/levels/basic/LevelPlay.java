package biitworx.games.race.riddle.riddlerace.levels.basic;


import biitworx.games.race.riddle.riddlerace.MainMenu;
import biitworx.games.race.riddle.riddlerace.MainView;

public class LevelPlay extends MainView {


    @Override
    protected void initViews() {

        getPlacementCircleView(MainMenu.levelItem.getName());



    }


}
